package com.example.myapplication;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

}