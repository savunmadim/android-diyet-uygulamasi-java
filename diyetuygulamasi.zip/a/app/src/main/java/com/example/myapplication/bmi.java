package com.example.myapplication;

import android.icu.text.DecimalFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class bmi extends AppCompatActivity {




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi);
        myButtonListenerMethod();
    }

    public void myButtonListenerMethod() {
        Button button = findViewById(R.id.btn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText boyText = findViewById(R.id.boy);
                String boyStr = boyText.getText().toString();
                double boy = Double.parseDouble(boyStr);
                double boym = boy / 100;
                final EditText kiloText = findViewById(R.id.kilo);
                String kiloStr = kiloText.getText().toString();
                double kilo = Double.parseDouble(kiloStr);
                double bmi = (kilo) / (boym * boym);
                DecimalFormat df = new DecimalFormat("#.#");
                double bmi_trimmed = Double.parseDouble(df.format(bmi));
                final TextView bmisonuc = findViewById(R.id.sonuc);
                bmisonuc.setText(Double.toString(bmi_trimmed));
                String bmitur;
                if (bmi < 15) {
                    bmitur = "Çok fazla zayıf";
                } else if (bmi >= 15 && bmi < 16) {
                    bmitur = "Çok zayıf";
                } else if (bmi >= 16 && bmi < 18.5) {
                    bmitur = "Zayıf";
                } else if (bmi >= 18.5 && bmi < 25) {
                    bmitur = "Normal";
                } else if (bmi >= 25 && bmi < 30) {
                    bmitur = "Kilolu";
                } else if (bmi >= 30 && bmi < 35) {
                    bmitur = "Kısmi Obez";
                } else if (bmi >= 35 && bmi < 40) {
                    bmitur = "Obez";
                } else {
                    bmitur = "Aşırı Obez";
                }
                final TextView bmikat = findViewById(R.id.bmiCat);
                bmikat.setText(bmitur);
            }


        });
    }



}