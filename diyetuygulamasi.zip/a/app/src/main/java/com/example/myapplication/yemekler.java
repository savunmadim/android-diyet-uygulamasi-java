package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class yemekler extends AppCompatActivity {
ListView listView;

    int[] imageId = {R.drawable.resim1, R.drawable.resim2, R.drawable.resim3, R.drawable.resim4, R.drawable.resim5, R.drawable.resim6};
    String[] name = {"Zeytinyağlı Börülce", "Kereviz Yemeği", "Smoothie Kasesi", "Ekşili Nohut Salata", "Hindi Göğüs", "Poşe Somon"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.yemekler);
        listView = findViewById(R.id.listView);
        CusAdapter cusAdapter = new CusAdapter();
        listView.setAdapter(cusAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {

                    startActivity(new Intent(getApplicationContext(), borulce.class));
                    overridePendingTransition(0, 0);
                }
                if (position == 1) {

                    startActivity(new Intent(getApplicationContext(), kereviz.class));
                    overridePendingTransition(0, 0);
                }

                if (position == 2) {

                    startActivity(new Intent(getApplicationContext(), smoothie.class));
                    overridePendingTransition(0, 0);
                }

                if (position == 3) {

                    startActivity(new Intent(getApplicationContext(), nohut.class));
                    overridePendingTransition(0, 0);
                }

                if (position == 4) {

                    startActivity(new Intent(getApplicationContext(), hindi.class));
                    overridePendingTransition(0, 0);
                }

                if (position == 5) {

                    startActivity(new Intent(getApplicationContext(), somon.class));
                    overridePendingTransition(0, 0);
                }


            }

        });
    }

    private class CusAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return imageId.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup parent) {
            View view1 = getLayoutInflater().inflate(R.layout.listitem, null);

            TextView yemekadı = view1.findViewById(R.id.personName);
            ImageView image = view1.findViewById(R.id.images);
            TextView detay = view1.findViewById(R.id.lastMessage);


            yemekadı.setText(name[i]);
            image.setImageResource(imageId[i]);

            return view1;
        }
    }

}
