package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.navigation.NavigationView;

public class login extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final TextView username = (TextView) findViewById(R.id.email);
        final TextView password = (TextView) findViewById(R.id.sifre);

        Button loginbutton = (Button)
                findViewById(R.id.loginbutton);
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("admin@admin.com")
                        && password.getText().toString().equals("admin"))
                {
                    Toast.makeText(login.this, "Giriş Başarılı", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                } else if
                (username.getText().toString().equals("akin@gmail.com") &&
                                password.getText().toString().equals("12345")) {
                    Toast.makeText(login.this, "Giriş Başarılı", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                } else if
                (username.getText().toString().equals("betul@gmail.com") &&
                                password.getText().toString().equals("11111")) {
                    Toast.makeText(login.this, "Giriş Başarılı", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                } else if
                (username.getText().toString().equals("coskun@gmail.com") &&
                                password.getText().toString().equals("54321")) {
                    Toast.makeText(login.this, "Giriş Başarılı", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                } else if
                (username.getText().toString().equals("ilke@gmail.com") &&
                                password.getText().toString().equals("1212")) {
                    Toast.makeText(login.this, "Giriş Başarılı", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                } else if
                (username.getText().toString().equals("mete@gmail.com") &&
                                password.getText().toString().equals("123")) {
                    Toast.makeText(login.this, "Giriş Başarılı", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                    overridePendingTransition(0, 0);
                } else
                    Toast.makeText(login.this, "Kullanıcı adı veya şifre hatalı, Giriş Başarısız",
                            Toast.LENGTH_SHORT).show();
            }

        });


    }
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.BMI:
                startActivity(new Intent(getApplicationContext(), bmi.class));
                overridePendingTransition(0, 0);
                return true;
            case R.id.home:
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                overridePendingTransition(0, 0);
                return true;

            case R.id.login:
                return true;

            case R.id.gallery:
                startActivity(new Intent(getApplicationContext(), gallery.class));
                overridePendingTransition(0, 0);
                return true;

            case R.id.yemekler:
                startActivity(new Intent(getApplicationContext(), yemekler.class));
                overridePendingTransition(0, 0);
                return true;

        }
        return false;
    }
}

