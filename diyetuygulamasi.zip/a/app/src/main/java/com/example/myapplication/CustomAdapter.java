package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {


    private Context context;
    private ArrayList<grids> gridsler;

    public CustomAdapter(Context context, ArrayList<grids> gridsler){
        this.context = context;
        this.gridsler = gridsler;
    }

    @Override
    public int getCount() {
        return gridsler.size();
    }

    @Override
    public Object getItem(int i) {
        return gridsler.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = LayoutInflater.from(context).
                    inflate(R.layout.grid_view, viewGroup, false);
        }
        grids mevcutFilm = (grids) getItem(i);

        TextView textViewyemekAdi = (TextView)
                view.findViewById(R.id.item_name);

        ImageView imageViewPoster = (ImageView)
                view.findViewById(R.id.grid_image);

        textViewyemekAdi.setText(mevcutFilm.getName());

        imageViewPoster.setImageResource(mevcutFilm.getImageId());

        return view;


    }
}