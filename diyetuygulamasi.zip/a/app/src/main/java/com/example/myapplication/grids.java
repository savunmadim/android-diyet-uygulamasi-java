package com.example.myapplication;

public class grids {
    private int imageId;
    private String name;

    public grids(int imageId, String name) {
    this.imageId = imageId;
    this.name = name;
    }
    public int getImageId() {
        return imageId;
    }
    public void setImageId(int imageId) {
        this.imageId = imageId;
    }
    public String getName() {
        return name;
    }
    public void setFilmadi (String name) {
        this.name = name;
    }
}
