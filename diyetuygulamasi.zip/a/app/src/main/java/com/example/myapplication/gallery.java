package com.example.myapplication;

import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;

public class gallery extends AppCompatActivity {
    NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        grids resim1 = new grids(R.drawable.resim1, "Zeytinyağlı Börülce");
        grids resim2 = new grids(R.drawable.resim2, "Kereviz Yemeği");
        grids resim3 = new grids(R.drawable.resim3, "Smoothie Kasesi");
        grids resim4 = new grids(R.drawable.resim4, "Ekşili Nohut Salata");
        grids resim5 = new grids(R.drawable.resim5, "Hindi Göğüs");
        grids resim6 = new grids(R.drawable.resim6, "Poşe Somon");

        ArrayList<grids> gridler =new ArrayList<grids>();
        gridler.add(resim1);
        gridler.add(resim2);
        gridler.add(resim3);
        gridler.add(resim4);
        gridler.add(resim5);
        gridler.add(resim6);

        CustomAdapter adapter = new CustomAdapter(this, gridler);
        GridView gridView = (GridView) findViewById(R.id.grid_view);
        gridView.setAdapter(adapter);


    }


}

